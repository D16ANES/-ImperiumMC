(() => {
  const state = {
    catalog: null,
    activeCategory: "ranks",
    cart: [], // array de product ids
  };

  const grid = document.getElementById("tienda");
  const tabsEl = document.getElementById("tabs");
  const hotbarSlots = document.getElementById("hotbarSlots");
  const hotbarCount = document.getElementById("hotbarCount");
  const hotbarTotal = document.getElementById("hotbarTotal");
  const checkoutBtn = document.getElementById("checkoutBtn");
  const modalOverlay = document.getElementById("modalOverlay");
  const modalClose = document.getElementById("modalClose");
  const modalSummary = document.getElementById("modalSummary");
  const modalError = document.getElementById("modalError");
  const modalPayBtn = document.getElementById("modalPayBtn");
  const playerNameInput = document.getElementById("playerName");
  const ipValue = document.getElementById("ipValue");
  const ipCopyBtn = document.getElementById("ipCopyBtn");

  const formatPrice = (cents) =>
    (cents / 100).toLocaleString("es-ES", { minimumFractionDigits: 2 }) + " €";

  async function loadCatalog() {
    const res = await fetch("/api/catalog");
    state.catalog = await res.json();
    ipValue.textContent = state.catalog.server.ip;
    document.title = `${state.catalog.server.name} — Tienda`;
    renderProducts();
  }

  function renderProducts() {
    const products = state.catalog.products.filter(
      (p) => p.category === state.activeCategory
    );
    grid.innerHTML = "";
    products.forEach((p) => {
      const card = document.createElement("article");
      card.className = "card";
      card.innerHTML = `
        <div class="card-icon">${p.icon}</div>
        <h3 class="card-name">${p.name}</h3>
        <p class="card-desc">${p.description}</p>
        <div class="card-footer">
          <span class="card-price">${formatPrice(p.price)}</span>
          <button class="card-add" data-id="${p.id}">Añadir</button>
        </div>
      `;
      grid.appendChild(card);
    });

    grid.querySelectorAll(".card-add").forEach((btn) => {
      btn.addEventListener("click", () => addToCart(btn.dataset.id, btn));
    });
  }

  function addToCart(id, btn) {
    state.cart.push(id);
    renderHotbar();
    if (btn) {
      const original = btn.textContent;
      btn.textContent = "Añadido ✓";
      btn.classList.add("added");
      setTimeout(() => {
        btn.textContent = original;
        btn.classList.remove("added");
      }, 700);
    }
  }

  function renderHotbar() {
    hotbarSlots.innerHTML = "";
    const visible = state.cart.slice(0, 8);
    const overflow = state.cart.length - visible.length;

    visible.forEach((id) => {
      const product = state.catalog.products.find((p) => p.id === id);
      const slot = document.createElement("div");
      slot.className = "slot filled";
      slot.textContent = product ? product.icon : "?";
      hotbarSlots.appendChild(slot);
    });

    for (let i = visible.length; i < 8; i++) {
      const slot = document.createElement("div");
      slot.className = "slot";
      hotbarSlots.appendChild(slot);
    }

    if (overflow > 0) {
      const slot = document.createElement("div");
      slot.className = "slot filled overflow";
      slot.textContent = `+${overflow}`;
      hotbarSlots.appendChild(slot);
    }

    const total = state.cart.reduce((sum, id) => {
      const product = state.catalog.products.find((p) => p.id === id);
      return sum + (product ? product.price : 0);
    }, 0);

    hotbarCount.textContent = `${state.cart.length} objeto${state.cart.length === 1 ? "" : "s"}`;
    hotbarTotal.textContent = formatPrice(total);
    checkoutBtn.disabled = state.cart.length === 0;
  }

  function renderModalSummary() {
    const grouped = {};
    state.cart.forEach((id) => {
      grouped[id] = (grouped[id] || 0) + 1;
    });

    let html = "";
    let total = 0;
    Object.entries(grouped).forEach(([id, qty]) => {
      const product = state.catalog.products.find((p) => p.id === id);
      if (!product) return;
      const subtotal = product.price * qty;
      total += subtotal;
      html += `<div class="modal-summary-row"><span>${product.icon} ${product.name} x${qty}</span><span>${formatPrice(subtotal)}</span></div>`;
    });
    html += `<div class="modal-summary-row total"><span>Total</span><span>${formatPrice(total)}</span></div>`;
    modalSummary.innerHTML = html;
  }

  // Tabs
  tabsEl.querySelectorAll(".tab").forEach((tab) => {
    tab.addEventListener("click", () => {
      tabsEl.querySelectorAll(".tab").forEach((t) => t.classList.remove("active"));
      tab.classList.add("active");
      state.activeCategory = tab.dataset.category;
      renderProducts();
    });
  });

  // Copiar IP
  ipCopyBtn.addEventListener("click", () => {
    navigator.clipboard.writeText(ipValue.textContent).then(() => {
      const original = ipCopyBtn.textContent;
      ipCopyBtn.textContent = "¡Copiada!";
      setTimeout(() => (ipCopyBtn.textContent = original), 1200);
    });
  });

  // Abrir / cerrar modal
  checkoutBtn.addEventListener("click", () => {
    modalError.textContent = "";
    renderModalSummary();
    modalOverlay.classList.add("open");
    playerNameInput.focus();
  });

  modalClose.addEventListener("click", () => modalOverlay.classList.remove("open"));
  modalOverlay.addEventListener("click", (e) => {
    if (e.target === modalOverlay) modalOverlay.classList.remove("open");
  });

  // Confirmar y crear sesión de pago
  modalPayBtn.addEventListener("click", async () => {
    const player = playerNameInput.value.trim();
    modalError.textContent = "";

    if (!/^[a-zA-Z0-9_]{3,16}$/.test(player)) {
      modalError.textContent = "Escribe un nombre de usuario válido (3-16 caracteres, sin espacios).";
      return;
    }

    modalPayBtn.disabled = true;
    modalPayBtn.textContent = "Redirigiendo...";

    try {
      const res = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ player, itemIds: state.cart }),
      });
      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || "No se pudo iniciar el pago.");
      }

      window.location.href = data.url;
    } catch (err) {
      modalError.textContent = err.message;
      modalPayBtn.disabled = false;
      modalPayBtn.textContent = "Ir a pagar";
    }
  });

  loadCatalog();
})();
