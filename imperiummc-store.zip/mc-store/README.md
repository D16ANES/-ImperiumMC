# 🏰 Tienda ImperiumMC

Tienda online con pagos reales (Stripe) y entrega automática de rangos, kits y
monedas a tu servidor de Minecraft mediante RCON.

## ¿Qué incluye?

- **Frontend** (`public/`): catálogo, carrito estilo hotbar, checkout.
- **Backend** (`server.js`): crea sesiones de pago con Stripe y, cuando Stripe
  confirma el pago, se conecta a tu servidor por RCON y ejecuta el comando
  correspondiente (dar rango, dar kit, dar monedas...).
- **Catálogo editable** (`config/products.json`): añade, quita o cambia
  precios de productos sin tocar código.

---

## 1. Requisitos previos

- Node.js 18+ instalado (para probarlo en tu PC) — https://nodejs.org
- Una cuenta de Stripe (gratis) — https://dashboard.stripe.com/register
- Acceso al `server.properties` de tu servidor de Minecraft (para activar RCON)
- Un plugin de rangos/kits/economía que puedas controlar por comandos de
  consola (ej: LuckPerms para rangos, un plugin de kits, un plugin de
  economía tipo Vault + EssentialsX o similar). Los comandos de ejemplo en
  `config/products.json` usan sintaxis de LuckPerms/Essentials — cámbialos
  por los comandos exactos de tus propios plugins.

## 2. Activar RCON en tu servidor de Minecraft

En el archivo `server.properties` de tu servidor:

```
enable-rcon=true
rcon.port=25575
rcon.password=PON_AQUI_UNA_CLAVE_LARGA_Y_SECRETA
```

Reinicia el servidor. Asegúrate de que el puerto 25575 esté accesible desde
donde vayas a alojar la tienda (si usas un hosting de Minecraft, normalmente
solo necesitas abrir ese puerto en el firewall del panel).

## 3. Configurar tu catálogo

Edita `config/products.json`:

- `server.name` / `server.ip` / `server.discord`: los datos que se muestran
  en la tienda.
- Cada producto tiene un `command`, donde `{player}` se reemplaza
  automáticamente por el nombre de usuario que el comprador escriba.
  Ejemplo: `"lp user {player} parent add vip"` ejecuta ese comando exacto en
  la consola de tu servidor cuando se confirma el pago.
- `price` está en **céntimos** (499 = 4,99 €).

## 4. Configurar Stripe

1. Crea tu cuenta en https://dashboard.stripe.com
2. Ve a **Developers → API keys** y copia tu **Secret key** (empieza por
   `sk_test_...` en modo prueba, o `sk_live_...` en producción).
3. Copia `.env.example` como `.env` y pega esa clave en `STRIPE_SECRET_KEY`.
4. Más adelante, en el paso 6, configurarás el webhook y obtendrás
   `STRIPE_WEBHOOK_SECRET`.

## 5. Probarlo en tu propio ordenador (opcional pero recomendado)

```bash
npm install
cp .env.example .env
# edita .env con tus datos
npm start
```

Abre `http://localhost:3000`. Para probar pagos usa la [tarjeta de prueba de
Stripe](https://docs.stripe.com/testing): `4242 4242 4242 4242`, cualquier
fecha futura y cualquier CVC.

Para probar el webhook en local, instala el
[Stripe CLI](https://docs.stripe.com/stripe-cli) y ejecuta:

```bash
stripe listen --forward-to localhost:3000/webhook
```

Te dará un `whsec_...` temporal para pruebas locales.

## 6. Desplegarlo en internet (gratis/barato)

Recomendado para empezar: **Railway** o **Render** (ambos tienen plan
gratuito/muy barato y son sencillos).

### Con Railway (https://railway.app)
1. Crea cuenta con GitHub.
2. Sube esta carpeta a un repositorio de GitHub.
3. En Railway: **New Project → Deploy from GitHub repo** → selecciona el repo.
4. En **Variables**, añade todas las variables de tu `.env` (Stripe, RCON, etc).
5. En `PUBLIC_URL`, pon la URL que Railway te asigna (ej:
   `https://imperiummc-store.up.railway.app`).
6. Railway lo despliega solo. Ya tienes tu tienda en internet.

### Configurar el webhook de Stripe con la URL real
1. Ve a **Stripe Dashboard → Developers → Webhooks → Add endpoint**.
2. URL del endpoint: `https://TU-DOMINIO/webhook`
3. Evento a escuchar: `checkout.session.completed`
4. Copia el **Signing secret** (`whsec_...`) y ponlo en la variable
   `STRIPE_WEBHOOK_SECRET` de tu hosting.

## 7. Conectar tu propio dominio (opcional)

Compra un dominio (Namecheap, Google Domains, etc.) y en Railway/Render ve a
**Settings → Domains → Add custom domain**, sigue sus instrucciones para
apuntar el DNS. Actualiza `PUBLIC_URL` en tus variables de entorno cuando lo
tengas.

## 8. Pasar a pagos reales (modo "live")

Mientras pruebas, usa las claves `sk_test_...`. Cuando todo funcione:
1. Activa tu cuenta de Stripe (verificación de identidad/negocio).
2. Cambia a las claves `sk_live_...` y crea un webhook nuevo en modo live.
3. Stripe cobra automáticamente una pequeña comisión por transacción
   (consulta las tarifas vigentes en stripe.com/pricing).

## ¿Y PayPal?

Este proyecto usa Stripe porque es más simple de integrar y acepta tarjetas
de todo el mundo. Si prefieres PayPal en vez de (o además de) Stripe, puedo
adaptarte el backend para usar el SDK de PayPal Checkout — dímelo y lo
preparo.

## Estructura del proyecto

```
mc-store/
├── server.js              # Backend: Stripe + entrega por RCON
├── package.json
├── .env.example            # Plantilla de variables de entorno
├── config/
│   ├── products.json      # Catálogo editable
│   └── orders.json        # Se crea solo, guarda historial de compras
└── public/
    ├── index.html         # Tienda
    ├── exito.html         # Página post-pago
    ├── styles.css
    └── app.js
```

## Seguridad

- Nunca subas tu archivo `.env` real a GitHub (ya está pensado para usar
  variables de entorno en el hosting, no el archivo).
- La contraseña de RCON debe ser larga y distinta a otras contraseñas tuyas.
- El servidor valida el nombre de usuario y los productos contra el
  catálogo antes de crear cualquier cobro, para evitar manipulación de
  precios desde el navegador.
