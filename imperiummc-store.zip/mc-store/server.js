require("dotenv").config();
const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");
const Stripe = require("stripe");
const { Rcon } = require("rcon-client");

const stripe = Stripe(process.env.STRIPE_SECRET_KEY);
const app = express();

const PRODUCTS_PATH = path.join(__dirname, "config", "products.json");
const ORDERS_PATH = path.join(__dirname, "config", "orders.json");

function loadCatalog() {
  return JSON.parse(fs.readFileSync(PRODUCTS_PATH, "utf-8"));
}

function saveOrder(order) {
  let orders = [];
  if (fs.existsSync(ORDERS_PATH)) {
    orders = JSON.parse(fs.readFileSync(ORDERS_PATH, "utf-8"));
  }
  orders.push(order);
  fs.writeFileSync(ORDERS_PATH, JSON.stringify(orders, null, 2));
}

// El webhook de Stripe necesita el body "crudo" (raw), así que se registra
// ANTES que express.json() y solo para esa ruta.
app.post(
  "/webhook",
  express.raw({ type: "application/json" }),
  async (req, res) => {
    let event;
    try {
      const sig = req.headers["stripe-signature"];
      event = stripe.webhooks.constructEvent(
        req.body,
        sig,
        process.env.STRIPE_WEBHOOK_SECRET
      );
    } catch (err) {
      console.error("Webhook inválido:", err.message);
      return res.status(400).send(`Webhook Error: ${err.message}`);
    }

    if (event.type === "checkout.session.completed") {
      const session = event.data.object;
      const player = session.metadata.player;
      const itemIds = JSON.parse(session.metadata.itemIds || "[]");

      try {
        await deliverItems(player, itemIds);
        saveOrder({
          date: new Date().toISOString(),
          player,
          itemIds,
          amount_total: session.amount_total,
          status: "delivered",
        });
        console.log(`✅ Entregado a ${player}:`, itemIds);
      } catch (err) {
        console.error("❌ Error entregando por RCON:", err.message);
        saveOrder({
          date: new Date().toISOString(),
          player,
          itemIds,
          amount_total: session.amount_total,
          status: "failed",
          error: err.message,
        });
      }
    }

    res.json({ received: true });
  }
);

// A partir de aquí, JSON normal para el resto de rutas.
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// Devuelve el catálogo (server info + productos) al frontend.
app.get("/api/catalog", (req, res) => {
  res.json(loadCatalog());
});

// Crea una sesión de pago de Stripe a partir del carrito recibido.
app.post("/api/checkout", async (req, res) => {
  try {
    const { player, itemIds } = req.body;

    if (!player || !/^[a-zA-Z0-9_]{3,16}$/.test(player)) {
      return res.status(400).json({
        error: "Nombre de usuario de Minecraft inválido (3-16 caracteres, sin espacios).",
      });
    }
    if (!Array.isArray(itemIds) || itemIds.length === 0) {
      return res.status(400).json({ error: "El carrito está vacío." });
    }

    const catalog = loadCatalog();
    const line_items = [];

    for (const id of itemIds) {
      const product = catalog.products.find((p) => p.id === id);
      if (!product) {
        return res.status(400).json({ error: `Producto no válido: ${id}` });
      }
      line_items.push({
        price_data: {
          currency: "eur",
          product_data: {
            name: `${product.name} (${catalog.server.name})`,
            description: product.description,
          },
          unit_amount: product.price,
        },
        quantity: 1,
      });
    }

    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      payment_method_types: ["card"],
      line_items,
      success_url: `${process.env.PUBLIC_URL}/exito.html?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.PUBLIC_URL}/`,
      metadata: {
        player,
        itemIds: JSON.stringify(itemIds),
      },
    });

    res.json({ url: session.url });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "No se pudo crear la sesión de pago." });
  }
});

// Ejecuta los comandos RCON correspondientes a cada producto comprado.
async function deliverItems(player, itemIds) {
  const catalog = loadCatalog();
  const rcon = await Rcon.connect({
    host: process.env.RCON_HOST,
    port: Number(process.env.RCON_PORT),
    password: process.env.RCON_PASSWORD,
  });

  try {
    for (const id of itemIds) {
      const product = catalog.products.find((p) => p.id === id);
      if (!product) continue;
      const command = product.command.replace("{player}", player);
      const result = await rcon.send(command);
      console.log(`RCON > ${command} -> ${result}`);
    }
  } finally {
    await rcon.end();
  }
}

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🏰 ImperiumMC Store corriendo en http://localhost:${PORT}`);
});
